-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Oct 16, 2025 at 05:58 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mcc_asset_management`
--

-- --------------------------------------------------------

--
-- Table structure for table `assets`
--

CREATE TABLE `assets` (
  `id` int(11) NOT NULL,
  `serial_number` varchar(50) NOT NULL,
  `name` varchar(100) NOT NULL,
  `description` text DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `purchase_date` date DEFAULT NULL,
  `purchase_cost` decimal(10,2) DEFAULT NULL,
  `supplier` varchar(100) DEFAULT NULL,
  `warranty_expiry` date DEFAULT NULL,
  `status` enum('active','borrowed','maintenance','inactive','disposed') DEFAULT 'active',
  `condition_status` enum('excellent','good','fair','poor') DEFAULT 'good',
  `location` varchar(100) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assets`
--

INSERT INTO `assets` (`id`, `serial_number`, `name`, `description`, `category_id`, `department_id`, `purchase_date`, `purchase_cost`, `supplier`, `warranty_expiry`, `status`, `condition_status`, `location`, `notes`, `created_at`, `updated_at`) VALUES
(1, 'ASSET-2024-001', 'Dell Optiplex 3070 Desktop', 'Desktop computer for general use', 1, 1, '2024-01-15', 35000.00, NULL, NULL, 'active', 'good', 'SOT Lab 1', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(2, 'ASSET-2024-002', 'Epson Projector EB-980W', 'Wireless projector for presentations', 2, 4, '2024-02-10', 45000.00, NULL, NULL, 'maintenance', 'good', 'Computer Lab 25', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(3, 'ASSET-2024-003', 'HP Laptop ProBook 450 G8', 'Laptop for mobile computing', 1, 2, '2024-03-05', 42000.00, NULL, NULL, 'borrowed', 'good', 'SOE Faculty', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(4, 'ASSET-2024-004', 'Canon Camera EOS 80D', 'DSLR camera for documentation', 2, 3, '2024-01-20', 55000.00, NULL, NULL, 'active', 'good', 'SOB Media Room', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(5, 'ASSET-2024-005', 'Yamaha Audio System', 'Professional audio system', 2, 6, '2024-02-28', 38000.00, NULL, NULL, 'inactive', 'good', 'Speech Lab', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(6, 'ASSET-2024-006', 'Smart TV Samsung 55\"', 'Smart television for presentations', 2, 5, '2024-03-15', 48000.00, NULL, NULL, 'active', 'good', 'Computer Lab 22', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(7, 'ASSET-2024-007', 'Printer HP LaserJet Pro', 'Laser printer for documents', 5, 1, '2024-01-10', 25000.00, NULL, NULL, 'borrowed', 'good', 'SOT Office', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(8, 'ASSET-2024-008', 'Whiteboard Interactive 75\"', 'Interactive whiteboard', 2, 2, '2024-02-20', 65000.00, NULL, NULL, 'active', 'good', 'SOE Classroom', NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(9, 'ASSET-2023-001', 'Dell Optiplex 3070', NULL, NULL, 1, NULL, NULL, NULL, NULL, 'active', 'good', NULL, NULL, '2025-10-16 13:29:35', '2025-10-16 13:29:35');

-- --------------------------------------------------------

--
-- Table structure for table `asset_categories`
--

CREATE TABLE `asset_categories` (
  `id` int(11) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `asset_categories`
--

INSERT INTO `asset_categories` (`id`, `name`, `description`, `created_at`) VALUES
(1, 'Computer Equipment', 'Desktop computers, laptops, servers', '2025-10-16 12:39:18'),
(2, 'Audio Visual', 'Projectors, speakers, microphones', '2025-10-16 12:39:18'),
(3, 'Furniture', 'Desks, chairs, cabinets', '2025-10-16 12:39:18'),
(4, 'Laboratory Equipment', 'Scientific and technical equipment', '2025-10-16 12:39:18'),
(5, 'Office Equipment', 'Printers, scanners, phones', '2025-10-16 12:39:18');

-- --------------------------------------------------------

--
-- Table structure for table `asset_transactions`
--

CREATE TABLE `asset_transactions` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `transaction_type` enum('created','updated','borrowed','returned','maintenance','disposed') NOT NULL,
  `description` text DEFAULT NULL,
  `performed_by` int(11) DEFAULT NULL,
  `transaction_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `old_status` varchar(50) DEFAULT NULL,
  `new_status` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `borrow_applications`
--

CREATE TABLE `borrow_applications` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `borrower_name` varchar(100) NOT NULL,
  `borrower_id` varchar(50) DEFAULT NULL,
  `borrower_department` varchar(100) DEFAULT NULL,
  `borrower_contact` varchar(20) DEFAULT NULL,
  `borrower_email` varchar(100) DEFAULT NULL,
  `purpose` text NOT NULL,
  `requested_date` date NOT NULL,
  `expected_return_date` date NOT NULL,
  `actual_return_date` date DEFAULT NULL,
  `status` enum('pending','approved','rejected','borrowed','returned','overdue') DEFAULT 'pending',
  `approved_by` int(11) DEFAULT NULL,
  `approved_at` timestamp NULL DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `borrow_applications`
--

INSERT INTO `borrow_applications` (`id`, `asset_id`, `borrower_name`, `borrower_id`, `borrower_department`, `borrower_contact`, `borrower_email`, `purpose`, `requested_date`, `expected_return_date`, `actual_return_date`, `status`, `approved_by`, `approved_at`, `notes`, `created_at`, `updated_at`) VALUES
(1, 3, 'John Doe', 'EMP-001', 'School of Education', '09123456789', NULL, 'Faculty presentation preparation', '2024-09-01', '2024-09-15', NULL, 'borrowed', NULL, NULL, NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(2, 7, 'Jane Smith', 'EMP-002', 'School of Technology', '09987654321', NULL, 'Document printing for seminar', '2024-09-05', '2024-09-12', NULL, 'borrowed', NULL, NULL, NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(8, 9, 'Sample01', NULL, 'School of Technology', '09876543211', 'saging@test.com', 'sample', '2025-10-16', '2025-10-18', NULL, 'pending', NULL, NULL, 'Asset Description: sample. Department Tag: School of Technology. Location of Use: sample.', '2025-10-16 13:31:23', '2025-10-16 13:31:23'),
(9, 9, 'Sample01', 'BORR-20251016153603-753', 'School of Technology', '09876543211', 'saging@test.com', 'sample', '2025-10-16', '2025-10-18', NULL, 'pending', NULL, NULL, 'Asset Description: sample test 02. Department Tag: School of Technology. Location of Use: sample.', '2025-10-16 07:36:03', '2025-10-16 13:36:03');

-- --------------------------------------------------------

--
-- Table structure for table `departments`
--

CREATE TABLE `departments` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `code` varchar(20) NOT NULL,
  `description` text DEFAULT NULL,
  `head_name` varchar(100) DEFAULT NULL,
  `contact_number` varchar(20) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `location` varchar(100) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `departments`
--

INSERT INTO `departments` (`id`, `name`, `code`, `description`, `head_name`, `contact_number`, `email`, `location`, `created_at`, `updated_at`) VALUES
(1, 'School of Technology', 'SOT', 'Information Technology and Engineering Programs', NULL, NULL, NULL, 'Technology Building', '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(2, 'School of Education', 'SOE', 'Education and Teaching Programs', NULL, NULL, NULL, 'Education Building', '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(3, 'School of Business', 'SOB', 'Business and Management Programs', NULL, NULL, NULL, 'Business Building', '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(4, 'Computer Lab Room 25', 'CL25', 'Computer Laboratory 25', NULL, NULL, NULL, 'Technology Building Room 25', '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(5, 'Computer Lab Room 22', 'CL22', 'Computer Laboratory 22', NULL, NULL, NULL, 'Technology Building Room 22', '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(6, 'Speech Lab', 'SL', 'Speech and Communication Laboratory', NULL, NULL, NULL, 'Education Building', '2025-10-16 12:39:18', '2025-10-16 12:39:18');

-- --------------------------------------------------------

--
-- Table structure for table `maintenance_records`
--

CREATE TABLE `maintenance_records` (
  `id` int(11) NOT NULL,
  `asset_id` int(11) NOT NULL,
  `maintenance_type` enum('preventive','corrective','emergency') NOT NULL,
  `description` text NOT NULL,
  `technician_name` varchar(100) DEFAULT NULL,
  `start_date` date NOT NULL,
  `expected_completion_date` date DEFAULT NULL,
  `actual_completion_date` date DEFAULT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `status` enum('scheduled','in_progress','completed','cancelled') DEFAULT 'scheduled',
  `notes` text DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `maintenance_records`
--

INSERT INTO `maintenance_records` (`id`, `asset_id`, `maintenance_type`, `description`, `technician_name`, `start_date`, `expected_completion_date`, `actual_completion_date`, `cost`, `status`, `notes`, `created_by`, `created_at`, `updated_at`) VALUES
(1, 2, 'corrective', 'Projector lamp replacement and cleaning', 'Tech Support Team', '2024-09-10', '2024-09-12', NULL, NULL, 'in_progress', NULL, NULL, '2025-10-16 12:39:18', '2025-10-16 12:39:18');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `full_name` varchar(100) NOT NULL,
  `email` varchar(100) DEFAULT NULL,
  `role` enum('admin','staff','faculty') DEFAULT 'staff',
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `full_name`, `email`, `role`, `created_at`, `updated_at`) VALUES
(1, 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'System Administrator', 'admin@mcc.edu.ph', 'admin', '2025-10-16 12:39:18', '2025-10-16 12:39:18'),
(2, 'staff', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'Staff User', 'staff@mcc.edu.ph', 'staff', '2025-10-16 12:39:18', '2025-10-16 12:39:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assets`
--
ALTER TABLE `assets`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `serial_number` (`serial_number`),
  ADD KEY `category_id` (`category_id`),
  ADD KEY `department_id` (`department_id`);

--
-- Indexes for table `asset_categories`
--
ALTER TABLE `asset_categories`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `asset_transactions`
--
ALTER TABLE `asset_transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `performed_by` (`performed_by`);

--
-- Indexes for table `borrow_applications`
--
ALTER TABLE `borrow_applications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `approved_by` (`approved_by`);

--
-- Indexes for table `departments`
--
ALTER TABLE `departments`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Indexes for table `maintenance_records`
--
ALTER TABLE `maintenance_records`
  ADD PRIMARY KEY (`id`),
  ADD KEY `asset_id` (`asset_id`),
  ADD KEY `created_by` (`created_by`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assets`
--
ALTER TABLE `assets`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `asset_categories`
--
ALTER TABLE `asset_categories`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `asset_transactions`
--
ALTER TABLE `asset_transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `borrow_applications`
--
ALTER TABLE `borrow_applications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `departments`
--
ALTER TABLE `departments`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `maintenance_records`
--
ALTER TABLE `maintenance_records`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assets`
--
ALTER TABLE `assets`
  ADD CONSTRAINT `assets_ibfk_1` FOREIGN KEY (`category_id`) REFERENCES `asset_categories` (`id`),
  ADD CONSTRAINT `assets_ibfk_2` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`);

--
-- Constraints for table `asset_transactions`
--
ALTER TABLE `asset_transactions`
  ADD CONSTRAINT `asset_transactions_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`),
  ADD CONSTRAINT `asset_transactions_ibfk_2` FOREIGN KEY (`performed_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `borrow_applications`
--
ALTER TABLE `borrow_applications`
  ADD CONSTRAINT `borrow_applications_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`),
  ADD CONSTRAINT `borrow_applications_ibfk_2` FOREIGN KEY (`approved_by`) REFERENCES `users` (`id`);

--
-- Constraints for table `maintenance_records`
--
ALTER TABLE `maintenance_records`
  ADD CONSTRAINT `maintenance_records_ibfk_1` FOREIGN KEY (`asset_id`) REFERENCES `assets` (`id`),
  ADD CONSTRAINT `maintenance_records_ibfk_2` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
